<?php
	sleep(2);
?>

{
    images: [
        {name: 'Image one', url:'test.asp', size:46.5, lastmod: new Date(2007, 10, 29)},
        {name: 'Image Two', url:'test.asp', size:43.2, lastmod: new Date(2007, 10, 30)}
    ]
}