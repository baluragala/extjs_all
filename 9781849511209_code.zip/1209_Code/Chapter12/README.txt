Chapter 9
---------

The ExtJS files must be in a subdirectory of the examples, and the directory must be called "ext". No other set up is required.
