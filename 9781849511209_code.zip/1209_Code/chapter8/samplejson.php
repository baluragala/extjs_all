[
	{ text: 'Bee', buzzFactor: 10 },
	{ text: 'Cockroach', buzzFactor: 1 },
	{ text: 'Aardvark', buzzFactor: 0 }	
]