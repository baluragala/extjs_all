The files need to run from a proper web server so that the XMLHttpRequest (Ajax) actions work as expected. Simply copy all files to a http://localhost/ and make sure you have the ExtJS files a subdirectory called "ext".

xmltree.js contains the sample XML loader code from the chapter and isn't designed to run standalone without more work.